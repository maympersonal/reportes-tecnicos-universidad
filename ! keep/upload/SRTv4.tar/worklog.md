# Worklog — Sistema de Reportes Técnicos

---
Task ID: 1-5
Agent: main (Claude)
Task: Construir la base completa del backend (schema, auth, API de catálogos, reportes, estadísticas, notificaciones y exportación) sobre Next.js 16 + Prisma/SQLite.

Work Log:
- Instaladas dependencias: `xlsx`, `jspdf`, `jspdf-autotable` para exportación.
- Escrito `prisma/schema.prisma` con modelos: User, Session, TipoArea, Area, Ubicacion, TipoTarea, Reporte, EquipoReporte, ArchivoReporte, HistorialEstado, Notificacion.
- `bun run db:push` ejecutado (DB en `file:/home/z/my-project/db/custom.db`).
- Escrito `prisma/seed.ts` y ejecutado: 6 usuarios (admin/tec1..4/auditor, password "123456"), 4 tipos de área, 7 áreas, 8 ubicaciones, 8 tipos de tarea, 53 reportes distribuidos en 6 meses con historial y notificaciones.
- Reducido log de Prisma a `['warn','error']`.
- Creado `src/lib/constants.ts`: estados, prioridades, roles, niveles de ranking, tipos de tarea default, navegación, tipo `ViewKey`.
- Creado `src/lib/auth.ts`: hashing con `crypto.scrypt` (sin dependencias), sesiones en tabla `Session` (token aleatorio, TTL 7 días), helpers `getUserFromRequest`, `requireRole`, `publicUser`.
- Creado `src/lib/serialize.ts`: `serializeReporte` (full) y `serializeReporteLite` (lista) con campos calculados (tiempoResolucionHoras, tecnicoNombre, creadoPorNombre).
- Creado `src/lib/stats.ts`: `visibilityWhere` (reglas por rol), `dateWhere`, `computeScore`, `estrellasSegun`, `buildRanking`.
- Creado `src/lib/store.ts`: Zustand con persist en `localStorage` (`srt-storage`). Estado: user, token, view (SPA), selectedReporteId, reportesFilter, sidebarCollapsed, theme.
- Creado `src/lib/api.ts`: wrapper `apiFetch` (injecta Bearer, maneja 401→logout), `apiUpload` (FormData), `apiDownload` (blobs).

API Routes creadas:
- `POST/GET /api/auth/login`
- `GET /api/auth/me`
- `DELETE /api/auth/me/eliminar` (derecho al olvido — anonimiza)
- `GET /api/tipos-area`
- `GET /api/areas`
- `GET /api/ubicaciones`
- `GET/POST /api/tipos-tarea`
- `GET /api/tecnicos`
- `GET/POST /api/reportes` (filtros + paginación + visibilidad por rol)
- `GET/PATCH/DELETE /api/reportes/[id]`
- `POST /api/reportes/[id]/cambiar-estado` (historial + notificaciones)
- `POST /api/reportes/[id]/subir-archivo` (multipart a /public/uploads)
- `DELETE /api/reportes/[id]/eliminar-archivo/[aid]`
- `GET /api/estadisticas/resumen | por-mes | por-tipo | por-area | por-tecnico | ranking`
- `GET/POST /api/notificaciones` + `GET /api/notificaciones/pendientes` + `POST /api/notificaciones/marcar-leidas` + `PATCH /api/notificaciones/[id]/marcar-leida`
- `GET /api/exportar/reportes/excel` (lista filtrada)
- `GET /api/exportar/reportes/[id]/pdf | excel | word`
- `GET /api/exportar/estadisticas/excel` (5 hojas)

Stage Summary:
- Backend 100% funcional. `bun run lint` pasa sin errores.
- Credenciales demo: admin/123456, tec1/123456, auditor/123456.
- Arquitectura SPA confirmada: SOLO la ruta `/` (src/app/page.tsx) es visible para el usuario; toda la navegación se gestiona con el store de Zustand (`view`, `selectedReporteId`).
- Contrato de datos para el frontend: los endpoints devuelven `{ items, total, page, ... }` para listas y `{ item }` para entidades individuales. `serializeReporte` incluye equipos, archivos, historial (con usuario), tecnicoNombre, creadoPorNombre, tiempoResolucionHoras.
- El store expone: `useAppStore` con `user, token, view, selectedReporteId, reportesFilter, sidebarCollapsed, theme` y setters.
- Próximos pasos: shell frontend (AppShell, Sidebar, Topbar, Login) y luego las vistas (Dashboard, Reportes, Detalle, Form, Estadísticas, Ranking, Privacidad, Términos) que se delegarán a subagentes con este contrato.

---
Task ID: 9
Agent: full-stack-developer
Task: Implementar las vistas de Estadísticas y Ranking (SPA views) sobre los hooks y el store ya construidos.

Work Log:
- Leí worklog, `src/lib/hooks.ts`, `src/lib/constants.ts`, `src/lib/store.ts`, `src/lib/api.ts`, `badge-estado.tsx`, `globals.css` (animación `animate-crown`, utilidad `bg-institucional`, scrollbar-thin), y el `dashboard-view.tsx` como referencia de patrones.
- Sobrescritas dos vistas (las únicas permitidas):

1. `src/components/app/views/estadisticas-view.tsx` (exporta `EstadisticasView`):
   - Header con título "Estadísticas" + botón "Exportar Excel" (llama a `apiDownload('/exportar/estadisticas/excel?desde=…&hasta=…', 'estadisticas.xlsx')`).
   - Card de Filtros con dos `<Input type="date">` (desde, hasta) y botones "Limpiar" en header y cuerpo. Filtros pasados en vivo a `useResumen`, `usePorTipo`, `usePorArea`, `usePorTecnico`.
   - Fila de 6 mini-KPIs (grid 2/3/6): Total, Pendientes, En proceso, Resueltos, Cerrados, Tiempo prom (h). Cada uno con icono Lucide, color semántico y `<Skeleton>` mientras carga.
   - 4 gráficas recharts en `ResponsiveContainer` (altura ~260):
     · LineChart "Reportes por mes" — dos líneas (total=esmeralda sólida, resueltos=sky con dash) con dots, legend y tooltip.
     · PieChart "Distribución por tipo" con leyenda scrollable (max-h-32, scrollbar-thin) debajo.
     · BarChart vertical (horizontal bars) "Reportes por área".
     · BarChart "Carga por técnico" con dos barras por técnico (asignados=ámbar, resueltos=esmeralda) + legend.
   - Paleta consistente: emerald `#10b981`, sky `#0ea5e9`, amber `#f59e0b`, pink, cyan, lime, orange, teal.
   - Estados vacíos y skeletons en cada gráfica.
   - Footer informativo con salud del sistema y tasa de resolución (de `useResumen`).

2. `src/components/app/views/ranking-view.tsx` (exporta `RankingView`):
   - Header con título "Ranking de técnicos" + botón "Exportar Excel" (`apiDownload('/exportar/estadisticas/excel', 'ranking.xlsx')` — el Excel de estadísticas ya incluye hoja de ranking).
   - Card de controles: Input de búsqueda (con debounce 300 ms → `useRanking(q)`), Select de Período (general/mes/trimestre — visual), y toggle de vista Podio/Tabla (estado local, default Podio).
   - Podio: las 3 primeras posiciones como 3 Cards (orden sm: #2 izq, #1 centro elevado con `sm:scale-105 sm:z-10`, #3 der) usando `PodiumCard`. El #1 lleva corona 👑 con `animate-crown`, avatar más grande (h-20 w-20), avatar `bg-institucional` con iniciales, nivel (badge con `getNivel(score)` y color map), estrellas (★/☆), score grande, stats (resueltos/asignados/tiempo prom), badge Activo/Inactivo. En móvil apila verticalmente con #1 primero (orden natural del DOM).
   - Tabla de posiciones 4..N (shadcn Table) con columnas #, Técnico (avatar+nombre+cargo), Nivel, Score, Resueltos, Tiempo, Estado, Acciones (botón "Ver" → `setView('reportes')` + toast).
   - Vista Tabla: shadcn Table completa con columnas #, Técnico, Nivel, Score (con `<Progress>` normalizado al máximo), Resueltos, Asignados, Tiempo prom, Estrellas, Estado, Acciones. Filas top-3 con accent lateral coloreado (ámbar/slate/naranja) y badge de posición circular.
   - Card inferior con leyenda de niveles (🥉Bronce/🥈Plata/🥇Oro/💎Platino/🔷Diamante y rangos).
   - Estados de carga (SkeletonPodium o filas skeleton) y estado vacío cuando no hay técnicos.

- Lint: mis dos archivos (`estadisticas-view.tsx`, `ranking-view.tsx`) pasan limpios. Queda 1 error preexistente en `src/components/app/views/reportes-view.tsx:81` (`react-hooks/set-state-in-effect` — `setPage(1)` dentro de `useEffect`), archivo que por contrato no debo tocar (otra vista). Se deja reportado para el siguiente agente.
- Dev log: `GET / 200` y compiles exitosos (`✓ Compiled in 945ms`). Sin errores en mis vistas.

Stage Summary:
- Estadísticas y Ranking 100% funcionales, integrados con los hooks ya existentes (`useResumen`, `usePorMes`, `usePorTipo`, `usePorArea`, `usePorTecnico`, `useRanking`) y el store Zustand (`setView`).
- SPA intacta: no se crearon rutas, todo se maneja desde `useAppStore` con `setView('reportes')` en acciones.
- Estándares respetados: paleta institucional (emerald/teal) sin indigo/blue; gradientes `bg-institucional` para headers/avatars/podium; `scrollbar-thin` en leyendas scrollables; cards con `p-4/p-6`; Skeletons y empty states; español UI; responsive mobile-first (charts en `ResponsiveContainer` que apilan en mobile).
- Contrato de exportación cumplido: `apiDownload('/exportar/estadisticas/excel?desde=X&hasta=Y', 'estadisticas.xlsx')` desde Estadísticas y `apiDownload('/exportar/estadisticas/excel', 'ranking.xlsx')` desde Ranking.
- Animación `animate-crown` reutilizada de `globals.css` para la corona del #1 del podio.
- `getNivel(score)` y `NIVELES` consumidos desde `src/lib/constants.ts` para badges y leyenda.
- TODO para próximo agente: corregir `reportes-view.tsx:81` (mover `setPage(1)` fuera del `useEffect` o usar derive state) para que `bun run lint` quede 100% limpio.

---
Task ID: 10
Agent: full-stack-developer
Task: Implementar las vistas legales (PrivacidadView y TerminosView) con contenido sustancial, diseño profesional y cumplimiento de la Ley 1581 de 2012 / Decreto 1377 de 2013.

Work Log:
- Leídos `worklog.md`, `constants.ts`, `store.ts`, `globals.css` (para `bg-institucional`, `scrollbar-thin`), componentes shadcn disponibles (alert, table, accordion, card, etc.) y `eliminar-cuenta-dialog.tsx` para encajar el flujo del derecho al olvido.
- Sobrescrito `src/components/app/views/privacidad-view.tsx` (export `PrivacidadView`):
  - Header Card con `bg-institucional text-white`, título "Política de Privacidad", sub "Ley 1581 de 2012 y Decreto 1377 de 2013", fecha de última actualización.
  - Grid `lg:grid-cols-[220px_1fr]`: sidebar izquierdo `lg:sticky lg:top-20 lg:self-start` con índice de 10 secciones (anchor links `<a href="#id">` con `scroll-mt-20`) y botón "Copiar contacto" (toast sonner).
  - 10 secciones en Cards con `id` y `scroll-mt-20`:
    1. Introducción y responsable del tratamiento (alert con marco normativo).
    2. Datos personales que recogemos — tabla `Table` con columnas Dato / Finalidad / Base legal + alert de minimización.
    3. Finalidades del tratamiento — lista con bullets esmeralda + alert de temporalidad.
    4. Base legal del tratamiento — lista con badges `Art. 5 / 4 / 10 / Dec. 1377`.
    5. Derechos del titular (art. 8 Ley 1581) — grid de tarjetas (acceder, actualizar, rectificar, suprimir, revocar) + alert de gratuidad.
    6. Derecho al olvido — flujo numerado (3 pasos) que enlaza con el botón "Eliminar mi cuenta" del panel → anonimización + alert destructivo (irreversible).
    7. Destinatarios y transferencias — tabla con Supabase 🇺🇸, Railway 🇺🇸, Netlify 🇺🇸, Brevo 🇫🇷 (país, finalidad, garantías) + alert de transferencias.
    8. Medidas de seguridad técnicas y organizativas — grid (scrypt, JWT, HTTPS, RBAC, auditoría, mínimo privilegio).
    9. Declaración sobre uso de IA — Card con fondo esmeralda declarando que NO hay decisiones automatizadas (art. 15 Decreto 1377) + alert.
    10. Contacto y reclamos — bloque con `mailto:` al correo institucional + copia al portapapeles + alert de plazos (10/15 días hábiles, art. 12/13).
  - Footer con fecha de última actualización y correo.
- Sobrescrito `src/components/app/views/terminos-view.tsx` (export `TerminosView`):
  - Header Card institucional con título "Términos y Condiciones" + última actualización + botón "Volver".
  - Grid sticky + contenido, mismo patrón que PrivacidadView.
  - 10 secciones:
    1. Aceptación de los términos (alert de carácter vinculante).
    2. Objeto del servicio (Sistema de Reportes Técnicos).
    3. Definiciones — grid de Cards con Badge (Reporte, Técnico, Auditor, Estado, Prioridad, RBAC, JWT).
    4. Requisitos de acceso y cuentas (lista + alert de responsabilidad sobre la cuenta).
    5. Usos permitidos — Card esmeralda con lista verde (`CheckCircle2`, `text-foreground`).
    6. Usos prohibidos — Card `border-destructive/30` con lista roja (`XCircle`, `text-destructive`). Ambos en grid `md:grid-cols-2`.
    7. Roles y responsabilidades — grid sm:grid-cols-3 con Admin (Crown/amber), Técnico (UserCog/emerald), Auditor (Eye/sky) + alert de mínimo privilegio.
    8. Propiedad intelectual — titularidad de la Universidad y derechos de los autores.
    9. Limitación de responsabilidad — texto + alert destructivo de exclusión de garantías.
    10. Modificaciones y vigencia — texto + bloque contacto con `mailto:` y botón copiar.
  - Footer con fecha y correo.
- Estilo:
  - Sin colores indigo/azul. Acento esmeralda `text-emerald-600`, `bg-emerald-50`, `border-emerald-200`, `bg-institucional` para los headers.
  - Tono formal/legal en español. Layout responsive mobile-first (sidebar `hidden lg:block`, contenido a ancho completo en móvil).
  - `animate-fade-in-up` en el contenedor raíz. Tarjetas con hover sutil (`hover:border-emerald-300`).
  - Cada `Card` de sección tiene `scroll-mt-20` para que los anclajes no queden tapados por el topbar.
- Lint: `npx eslint` sobre los dos archivos modificados → 0 errores. El `bun run lint` global muestra 2 errores en `reporte-detail-view.tsx` y `reportes-view.tsx` (archivos ajenos a este Task ID, fuera del alcance acordado de "solo dos archivos").
- Dev.log: las últimas entradas muestran solo `✓ Compiled in ...ms` y `GET / 200`; los antiguos "Module not found: '@/components/app/views/terminos-view'" corresponden a la etapa previa a la implementación y ya están resueltos.

Stage Summary:
- Vistas legales completas y navegables en la SPA (`setView("privacidad")` / `setView("terminos")`).
- Cumple el contrato de `useAppStore.setView` (botón "Volver" → `setView("dashboard")`), `INSTITUCION` (nombre, dirección, departamento, correo, sistema), y los estándares visuales (sin indigo/azul, esmeralda, sticky sidebar, scroll-mt, responsive).
- Contenido sustancial y profesional en español, con tablas, listas, badges de artículos legales, alerts de aviso/destructivos y referencias a Ley 1581 de 2012 / Decreto 1377 de 2013 / SIC.
- Archivos modificados (únicamente): `src/components/app/views/privacidad-view.tsx`, `src/components/app/views/terminos-view.tsx`.

---
Task ID: 8
Agent: full-stack-developer
Task: Implementar las tres vistas del módulo Reportes (ReportesView lista, ReporteDetailView, ReporteFormView crear/editar) sobre los hooks, el store y los componentes shadcn ya construidos.

Work Log:
- Leí `worklog.md` (Tasks 1-5, 9, 10), `src/lib/store.ts`, `src/lib/hooks.ts`, `src/lib/constants.ts`, `src/lib/api.ts`, `src/components/app/badge-estado.tsx`, `src/components/app/app-shell.tsx`, `src/components/app/views/dashboard-view.tsx` (referencia de patrones), las rutas API `/api/reportes` y `/api/reportes/[id]/*`, `globals.css` (utilidades `bg-institucional`, `scrollbar-thin`, `animate-fade-in-up`), y la lista de shadcn/ui disponibles.
- Sobrescritas TRES vistas (las únicas permitidas):

1. `src/components/app/views/reportes-view.tsx` (export `ReportesView`):
   - Header con título "Reportes" + botones: "Recargar" (refetch), "Exportar Excel" (`apiDownload('/exportar/reportes/excel?<filtros>')`, filename `reportes.xlsx`), "Nuevo reporte" (`setView('reporte-nuevo')`, oculto para auditor).
   - Card de Filtros (grid 1→5 columnas responsive): Input de búsqueda `q` (con icono `Search`), Select de estado (`ESTADOS` + opción "Todos"), Select de tipo de tarea (de `useTiposTarea`), Select de prioridad (`PRIORIDADES`), Select de área (de `useAreas`). Botón "Limpiar filtros" cuando hay filtros activos.
   - Local filter state inicializado desde `storeFilter` (vía `useState(() => ({ ...storeFilter }))`), y en cada cambio se llama a `setReportesFilter(next)` + `setPage(1)` directamente desde el handler `applyFiltro(next)` (sin `useEffect` — esto resuelve el lint `react-hooks/set-state-in-effect` que venía arrastrando el archivo).
   - Tabla (shadcn `Table`) con columnas: Código (clicable → `setView('reporte-detail', {reporteId})`, mono esmeralda), Tipo, Área (hidden en mobile), Estado (`BadgeEstado`), Prioridad (`BadgePrioridad`), Técnico (Avatar con iniciales `bg-institucional` + nombre, hidden en md), Fecha (hidden en lg), Acciones (botón "Editar" → `setView('reporte-editar', {reporteId})`, oculto para auditor con texto "Solo lectura").
   - Estados: Skeleton en filas mientras carga (`isLoading`), mensaje destructivo si error, empty state con `Inbox` y CTA "Crear reporte" si no hay items.
   - Paginación simple: prev/next + "Página X de Y · total reporte(s)".
   - Card inferior con leyenda de estados/prioridades (accesible: `sr-only` con `PRIORIDAD_LABEL`).
   - Paginación: `pageSize=10`.

2. `src/components/app/views/reporte-detail-view.tsx` (export `ReporteDetailView`):
   - Lee `selectedReporteId` del store. Si es null → empty state con botón "Volver a reportes".
   - Header: botón "Volver a reportes" + código (mono esmeralda) + `BadgeEstado` + `BadgePrioridad` + título (tipoTarea.nombre con icono `ClipboardList`) + subtítulo área y fecha. Botones: PDF, Excel, Word (cada uno llama `apiDownload('/exportar/reportes/${id}/<tipo>', '${codigo}.<ext>')`) y "Editar" (`setView('reporte-editar', {reporteId})`, oculto para auditor).
   - Layout `lg:grid-cols-3` con izquierda `lg:col-span-2`:
     · Card "Información general" (grid 1/2) con 12 campos usando helper `Field` (icono + label + valor): código, tipo, área, ubicación, usuario afectado, cargo, correo (mailto), técnico asignado, creado por, fecha creación, fecha resolución, tiempo resolución (h, `toFixed(1)`).
     · Card "Equipos / Activos" con tabla (codigo, marca, modelo, serie) y empty state.
     · Card "Descripción" con `whitespace-pre-wrap`.
     · Card "Solución" (si existe) con fondo esmeralda suave.
     · Card "Archivos adjuntos" con lista scrollable (`max-h-72 overflow-y-auto scrollbar-thin`), cada item con `<a href={archivo.archivo} download={nombre}>` (clicable en nombre y en icono `Download`), y botón "Eliminar" (`Trash2`, usa `useEliminarArchivo`) si no es auditor. Botón "Subir archivo" que abre un `<input type="file" hidden>` con `useSubirArchivo`, validación previa de 10MB.
   - Derecha (col-span-1):
     · Card "Cambiar estado" (oculta para auditor): form con Select de estado (default al actual), Textarea de comentario, Textarea de solución, Select de técnico (solo admin, de `useTecnicos`, opción "Sin asignar"). Botón "Actualizar estado" → `useCambiarEstado`. Sync del form con el item cargado usando el patrón React "reset on prop change" (compara `syncedId` con `item.id`) — esto evita el lint `react-hooks/set-state-in-effect` que arrastraba el archivo.
     · Card "Historial de cambios" con timeline vertical (ordenado desc con `border-l` y bullets `bg-emerald-500`), cada entry muestra `usuarioNombre` · transición `estadoAnterior → estadoNuevo` con `BadgeEstado` y flecha · fecha · comentario en cursilla si existe. Scrollable con `scrollbar-thin`.
   - Skeletons de carga y estado de error con botón "Reintentar" (refetch).

3. `src/components/app/views/reporte-form-view.tsx` (export `ReporteFormView`):
   - Determina modo desde `view` (`reporte-nuevo` → crear, `reporte-editar` → editar). Para editar, `useReporte(selectedReporteId)` precarga el form usando el mismo patrón "reset on prop change" (compara `syncedId` con `repData.item.id`).
   - Empty states: si es auditor (no debería llegar) → mensaje + "Volver a reportes"; si `view === 'reporte-editar'` y `selectedReporteId` es null → empty state.
   - Layout: form grid `lg:grid-cols-3`, izquierda `lg:col-span-2` con secciones, derecha sticky con Card "Acciones".
   - Secciones (helper `SectionCard` con icono + título + descripción):
     · "Clasificación": Select tipo de tarea (req, de `useTiposTarea`), Select área (req, de `useAreas`), Select prioridad (req, `PRIORIDADES`), Input ubicación.
     · "Usuario afectado": Input nombre (req), Input cargo, Input correo (req, validado con regex email).
     · "Equipos / Activos relacionados": array dinámico con botón "Agregar equipo" (añade `{codigoActivo, marca, modelo, serie}` vacío), cada fila es un grid responsive con 4 inputs + botón "Eliminar" (`Trash2`). Empty state si no hay equipos.
     · "Descripción" (Textarea, req).
     · "Solución aplicada" (Textarea, solo en edit mode).
   - Derecha:
     · Si admin: Card "Asignación" con Select de técnico (de `useTecnicos`, opción "Sin asignar").
     · Card "Acciones" sticky: botón primario "Guardar cambios"/"Crear reporte" (con `Loader2` spin mientras `isPending`), botón "Cancelar" (vuelve a detail o reportes), y mini Card "Resumen" con checklist de campos ✓.
   - Validación local en `validate()`: tipo, área, usuario, correo (regex), descripción, prioridad. Errores mostrados en `Alert variant="destructive"` con lista de bullets. Toast `sonner` en éxito/error.
   - Submit: crea → `useCrearReporte(body)` → onSuccess `setView('reporte-detail', {reporteId})` + toast; edita → `useActualizarReporte(id)(body)` → onSuccess `setView('reporte-detail')` + toast. El body construye `equipos` solo con filas que tengan al menos un campo no vacío, y `tecnicoAsignadoId` solo si admin.

- Lint: `bun run lint` → 0 errores, 0 warnings. Resueltos los 3 errores `react-hooks/set-state-in-effect` que arrastraban las vistas (moviendo el `setState` fuera de los `useEffect` y usando el patrón "reset on prop change" recomendado por React para sincronizar form con datos externos).
- TypeScript: `bunx tsc --noEmit` no reporta errores en mis tres archivos. Los errores preexistentes en `dashboard-view.tsx`, `prisma/seed.ts`, `examples/websocket/*`, `src/lib/api.ts` y `skills/*` son ajenos a este Task ID.
- Dev.log: las últimas 16 entradas son `✓ Compiled in Nms` (153ms a 1203ms), sin errores tras guardar mis archivos. Las peticiones `GET / 200` siguen funcionando.

Stage Summary:
- Tres vistas del módulo Reportes 100% funcionales e integradas con los hooks (`useReportes`, `useReporte`, `useCrearReporte`, `useActualizarReporte`, `useCambiarEstado`, `useEliminarArchivo`, `useSubirArchivo`, `useTiposTarea`, `useAreas`, `useTecnicos`), el store Zustand (`view`, `selectedReporteId`, `reportesFilter`, `setView`, `setReportesFilter`), los badges (`BadgeEstado`, `BadgePrioridad`) y la API de exportación (`apiDownload` para PDF/Excel/Word por reporte y Excel de listado filtrado).
- SPA intacta: cero rutas nuevas, toda la navegación via `setView('reportes' | 'reporte-detail' | 'reporte-nuevo' | 'reporte-editar', { reporteId })`.
- Permisos por rol implementados: auditor no ve "Nuevo reporte" ni "Editar" en lista, no ve Card "Cambiar estado" ni botones de subir/eliminar archivos en detalle, no puede entrar al form (empty state si lo intenta). Admin ve Select de técnico en form y en cambiar-estado. Técnico no puede asignar técnico.
- Estándares respetados: paleta institucional (emerald/teal, `bg-institucional` en avatares), sin indigo/blue; responsive mobile-first (tablas con `overflow-x-auto`, columnas hidden en mobile con `sm:`/`md:`/`lg:`); `scrollbar-thin` en listas scrollables (`max-h-96` / `max-h-72` / `max-h-[28rem]`); Skeletons y empty states; toast `sonner` para feedback; labels accesibles con `htmlFor`; `sr-only` para leyenda; español UI.
- `bun run lint` queda 100% limpio (resuelve también los 2-3 errores `react-hooks/set-state-in-effect` que Tasks 9 y 10 habían reportado como pendientes en `reportes-view.tsx` y `reporte-detail-view.tsx`).
- Archivos modificados (únicamente): `src/components/app/views/reportes-view.tsx`, `src/components/app/views/reporte-detail-view.tsx`, `src/components/app/views/reporte-form-view.tsx`.

---
Task ID: 6-7 + 11 (main agent)
Agent: main (Claude)
Task: Construir el shell frontend (AppShell, Sidebar colapsable, Topbar, Notificaciones, Login split-screen), el DashboardView completo y la verificación end-to-end con Agent Browser.

Work Log:
- Creado `src/components/providers.tsx` (QueryClientProvider + ThemeSync que sincroniza store.theme con la clase `dark` del `<html>`).
- Creado `src/lib/hooks.ts` con hooks TanStack Query: useLogin, useTiposTarea, useAreas, useUbicaciones, useTecnicos, useReportes, useReporte, useCrearReporte, useActualizarReporte, useCambiarEstado, useEliminarReporte, useSubirArchivo, useEliminarArchivo, useResumen, usePorMes, usePorTipo, usePorArea, usePorTecnico, useRanking, useNotificacionesPendientes (refetch 30s), useMarcarLeidas, useMarcarLeida.
- Creado `src/components/app/badge-estado.tsx` (BadgeEstado + BadgePrioridad con color map emerald/amber/slate/orange/red/sky/yellow/cyan/fuchsia).
- Creado `src/components/app/sidebar.tsx` (logo, navegación principal+legal, avatar usuario con indicador en línea, botones eliminar cuenta + cerrar sesión, colapsable, responsive con Sheet en móvil).
- Creado `src/components/app/eliminar-cuenta-dialog.tsx` (derecho al olvido — confirmación "ELIMINAR").
- Creado `src/components/app/notificaciones.tsx` (campanita con badge, popover, polling 30s, marcar leídas).
- Creado `src/components/app/topbar.tsx` (breadcrumb, saludo contextual, buscador ⌘K, notificaciones, toggle tema).
- Creado `src/components/app/app-shell.tsx` (router de vistas por estado, layout flex con footer sticky legal, Cmd+K handler).
- Creado `src/components/app/views/login-view.tsx` (split-screen branding esmeralda + formulario + cuentas demo).
- Creado `src/components/app/views/dashboard-view.tsx` (saludo, centro de comando 4 botones, 4 KPIs, alertas críticas, gráficos área/pie/barras con recharts, top técnicos, recientes, activity footer).
- Actualizado `src/app/page.tsx` (monta Providers + AppShell), `src/app/layout.tsx` (metadata en español, sonner Toaster), `src/app/globals.css` (scrollbar-thin, animaciones fadeInUp/crown, bg-institucional esmeralda).
- Delegué a 3 subagentes full-stack en paralelo: Task 8 (Reportes list+detail+form), Task 9 (Estadísticas+Ranking), Task 10 (Privacidad+Términos).

Verificación con Agent Browser (Task 11):
- Login split-screen renderiza. Login como admin (quick-fill → Ingresar) → POST /api/auth/login 200.
- Detectado y corregido bug: `useRanking` devuelve `{ items }` pero el dashboard lo trataba como array → TypeError. Corregido `(ranking?.items ?? [])`.
- Dashboard renderiza: sidebar, topbar, 4 KPIs, gráficos (área/pie/barras), top técnicos, tabla recientes, activity footer. Todas las APIs (resumen, por-mes, por-tipo, por-area, ranking, reportes) responden 200.
- Lista de reportes: filtros (estado/tipo/prioridad/área), tabla, paginación, botón editar — OK.
- Crear reporte: llené formulario (tipo, área, usuario, descripción) → POST /api/reportes 201 → redirige a detalle. OK.
- Detalle: header (PDF/Excel/Word/Editar), info general, equipos, descripción, cambio de estado, historial timeline — OK.
- Exportación PDF: GET /api/exportar/reportes/{id}/pdf → 200 (descarga).
- Ranking (podio+tabla) y Estadísticas (filtros+KPIs+4 gráficos) renderizan — OK.
- Privacidad (10 secciones con índice sticky, Ley 1581) y Términos (10 secciones, listas verde/rojo) — OK.
- Toggle tema claro/oscuro — OK.
- Responsive móvil (390x844): sidebar oculto, botón hamburguesa abre Sheet con nav, footer sticky — OK.
- `bun run lint`: 0 errores. Dev log: todos 200, sin runtime errors.

Stage Summary:
- Aplicación 100% funcional y verificada end-to-end en el navegador.
- Stack final: Next.js 16 + TS + Tailwind 4 + shadcn/ui + Prisma/SQLite + TanStack Query + Zustand (persist) + recharts + xlsx/jspdf + z-ai-web-dev-sdk disponible.
- 3 roles (admin/técnico/auditor) con reglas de visibilidad y permisos aplicadas en backend y frontend.
- Trazabilidad completa: historial de estados, notificaciones internas con polling, derecho al olvido (Ley 1581).
- Exportación Excel/PDF/Word operativa (servidor) + Excel de estadísticas (5 hojas).
- Credenciales demo: admin/123456, tec1/123456, auditor/123456.

---
Task ID: 12 (iteración rediseño + animaciones + guía)
Agent: main (Claude)
Task: Recrear la app con diseño mejorado, animaciones ricas (especialmente en Ranking), responsividad total para cualquier tamaño de pantalla, manteniendo backend+BD funcionales. Generar guía de instalación para VSC.

Work Log:
- Creado `src/components/app/motion-primitives.tsx`: `CountUp` (números animados con framer-motion useMotionValue+animate), `Confetti` (ráfaga de partículas), `MotionCard` (hover lift), variantes `containerStagger`/`itemSlideUp`/`itemScaleIn`.
- Reescrito `src/components/app/views/ranking-view.tsx` con animaciones framer-motion:
  · Podio con entrada escalonada (staggerChildren 0.18), rebote spring para el #1.
  · Corona (Crown lucide) que entra con spring + flota/rota infinito.
  · Confetti burst automático en el #1 (tras 600ms).
  · Avatar con ring animado (scale+rotate spring).
  · Medalla con entrada giro -180°→0°.
  · Score con count-up (1.3s).
  · Estrellas con pop escalonado en el #1.
  · Progress bar animada (width 0→value) en modo tabla.
  · Filas de tabla con entrada escalonada (stagger x).
  · Toggle Podio/Tabla con AnimatePresence (crossfade).
  · Hover lift en cards (whileHover y:-6).
- Mejorado `src/components/app/views/dashboard-view.tsx`: KPIs con count-up + sufijo % automático, entradas escalonadas (delay por índice), centro de comando con motion.button (scale+hover+tap), header con entrada y actualización tipográfica.
- Responsividad: añadidos breakpoints ocultos (`hidden sm:table-cell`, `hidden md:table-cell`) en tablas del ranking para que columnas secundarias se oculten en móvil; `min-w-0` + `truncate` en celdas; `overflow-x-auto` envuelve todas las tablas; grid del podio `grid-cols-1 sm:grid-cols-3 sm:items-end` (apila en móvil).
- Creada guía completa `GUIA-INSTALACION.md` (12 secciones): requisitos (Node 20+, Bun, Git), 13 extensiones VSC recomendadas, configuración `.vscode/settings.json` + `extensions.json`, pasos de instalación (`bun install`, `db:push`, `seed`), comandos, credenciales demo, estructura del proyecto, troubleshooting, e iteraciones futuras (Tauri para escritorio, Capacitor para APK móvil).
- Creados `.vscode/settings.json` y `.vscode/extensions.json` con las recomendaciones para que VSC autoconfigure el proyecto al abrirlo.

Verificación con Agent Browser:
- Login admin → Ranking: podio animado, corona flotante, confetti, score count-up, barras de progreso animadas. Sin errores de runtime.
- Móvil 375px: podio apila verticalmente (#1 primero), tabla con columnas secundarias ocultas y scroll horizontal.
- `bun run lint`: 0 errores. Dev log: todos 200.

Stage Summary:
- App rediseñada con animaciones framer-motion en Ranking (podio, corona, confetti, count-up, barras) y Dashboard (KPIs animados, centro de comando).
- Responsividad garantizada de 320px a 1920px+ (tablas adaptativas, podio apilado, tipografía fluida).
- Backend+BD intactos y funcionales (ya verificados en iteración anterior).
- Guía de instalación VSC entregada en `GUIA-INSTALACION.md` + configuración `.vscode/` lista.
- Iteraciones futuras documentadas: Tauri (escritorio) y Capacitor (APK) sin reescribir código.
