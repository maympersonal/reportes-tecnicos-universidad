// Constantes del Sistema de Reportes Técnicos

export type Rol = "admin" | "tecnico" | "auditor"
export type Estado = "pendiente" | "en_proceso" | "resuelto" | "cerrado"
export type Prioridad = "baja" | "media" | "alta" | "critica"

export const ESTADOS: { value: Estado; label: string; color: string; emoji: string }[] = [
  { value: "pendiente", label: "Pendiente", color: "amber", emoji: "⏳" },
  { value: "en_proceso", label: "En proceso", color: "blue", emoji: "🔄" },
  { value: "resuelto", label: "Resuelto", color: "emerald", emoji: "✅" },
  { value: "cerrado", label: "Cerrado", color: "slate", emoji: "📦" },
]

export const PRIORIDADES: { value: Prioridad; label: string; color: string }[] = [
  { value: "baja", label: "Baja", color: "slate" },
  { value: "media", label: "Media", color: "amber" },
  { value: "alta", label: "Alta", color: "orange" },
  { value: "critica", label: "Crítica", color: "red" },
]

export const ROLES: { value: Rol; label: string }[] = [
  { value: "admin", label: "Administrador" },
  { value: "tecnico", label: "Técnico" },
  { value: "auditor", label: "Auditor" },
]

export const ESTADO_LABEL: Record<Estado, string> = {
  pendiente: "Pendiente",
  en_proceso: "En proceso",
  resuelto: "Resuelto",
  cerrado: "Cerrado",
}

export const PRIORIDAD_LABEL: Record<Prioridad, string> = {
  baja: "Baja",
  media: "Media",
  alta: "Alta",
  critica: "Crítica",
}

export const ROL_LABEL: Record<Rol, string> = {
  admin: "Administrador",
  tecnico: "Técnico",
  auditor: "Auditor",
}

// Tipos de tarea por defecto
export const TIPOS_TAREA_DEFAULT = [
  { codigo: "activos_fijos", nombre: "Activos fijos" },
  { codigo: "reparacion_hardware", nombre: "Reparación de hardware" },
  { codigo: "actualizacion_sistema", nombre: "Actualización de sistema" },
  { codigo: "recuperacion_cuentas", nombre: "Recuperación de cuentas" },
  { codigo: "mantenimiento_preventivo", nombre: "Mantenimiento preventivo" },
  { codigo: "soporte_red", nombre: "Soporte de red" },
  { codigo: "instalacion_software", nombre: "Instalación de software" },
  { codigo: "otros", nombre: "Otros" },
]

// Tipos de área por defecto
export const TIPOS_AREA_DEFAULT = [
  { nombre: "Académica", descripcion: "Áreas académicas y de docencia" },
  { nombre: "Administrativa", descripcion: "Áreas administrativas" },
  { nombre: "TI", descripcion: "Tecnologías de la información" },
  { nombre: "Servicios", descripcion: "Servicios generales" },
]

// Niveles del ranking
export const NIVELES = [
  { nombre: "Bronce", min: 0, color: "amber", icon: "🥉" },
  { nombre: "Plata", min: 200, color: "slate", icon: "🥈" },
  { nombre: "Oro", min: 400, color: "yellow", icon: "🥇" },
  { nombre: "Platino", min: 700, color: "cyan", icon: "💎" },
  { nombre: "Diamante", min: 1000, color: "fuchsia", icon: "🔷" },
]

export function getNivel(score: number) {
  return [...NIVELES].reverse().find((n) => score >= n.min) ?? NIVELES[0]
}

// Información institucional
export const INSTITUCION = {
  nombre: "Universidad",
  direccion: "Dirección de Innovación Digital",
  departamento: "Departamento de Desarrollo y Soporte",
  correo: "innovacion.did@iris.uh.cu",
  sistema: "Sistema de Reportes Técnicos",
}

// Navegación principal
export const NAV_ITEMS = [
  { view: "dashboard", label: "Inicio", icon: "LayoutDashboard" },
  { view: "reportes", label: "Reportes", icon: "ClipboardList" },
  { view: "ranking", label: "Ranking", icon: "Trophy" },
  { view: "estadisticas", label: "Estadísticas", icon: "BarChart3" },
] as const

export const NAV_LEGAL = [
  { view: "privacidad", label: "Privacidad", icon: "Shield" },
  { view: "terminos", label: "Términos", icon: "FileText" },
] as const

export type ViewKey =
  | "dashboard"
  | "reportes"
  | "reporte-detail"
  | "reporte-nuevo"
  | "reporte-editar"
  | "ranking"
  | "estadisticas"
  | "privacidad"
  | "terminos"
