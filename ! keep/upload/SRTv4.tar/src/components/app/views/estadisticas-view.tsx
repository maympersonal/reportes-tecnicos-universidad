"use client"

import { useState, useMemo } from "react"
import {
  useResumen,
  usePorMes,
  usePorTipo,
  usePorArea,
  usePorTecnico,
} from "@/lib/hooks"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Skeleton } from "@/components/ui/skeleton"
import { apiDownload } from "@/lib/api"
import { INSTITUCION } from "@/lib/constants"
import { toast } from "sonner"
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts"
import {
  FileSpreadsheet,
  Filter,
  X,
  Activity,
  Clock,
  CheckCircle2,
  ClipboardList,
  PackageCheck,
  ListChecks,
  BarChart3,
} from "lucide-react"

// Paleta institucional (esmeralda / sky / ámbar / fucsia)
const CHART_COLORS = [
  "#10b981", // emerald
  "#0ea5e9", // sky
  "#f59e0b", // amber
  "#ec4899", // pink
  "#06b6d4", // cyan
  "#84cc16", // lime
  "#f97316", // orange
  "#14b8a6", // teal
]

const COLOR_TOTAL = "#10b981"
const COLOR_RESUELTOS = "#0ea5e9"
const COLOR_ASIGNADOS = "#f59e0b"

type KpiProps = {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: React.ReactNode
  sub?: string
  iconColor?: string
  loading?: boolean
}

function KpiCard({ icon: Icon, label, value, sub, iconColor = "text-emerald-600", loading }: KpiProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground">{label}</p>
            {loading ? (
              <Skeleton className="mt-1 h-7 w-16" />
            ) : (
              <p className="mt-1 text-2xl font-bold tracking-tight">{value}</p>
            )}
            {sub && <p className="mt-0.5 text-[11px] text-muted-foreground">{sub}</p>}
          </div>
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
            <Icon className={`h-5 w-5 ${iconColor}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ChartCard({
  title,
  description,
  children,
  className,
}: {
  title: string
  description?: string
  children: React.ReactNode
  className?: string
}) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  )
}

function ChartSkeleton() {
  return <Skeleton className="h-[260px] w-full" />
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex h-[200px] w-full flex-col items-center justify-center gap-2 text-center text-sm text-muted-foreground">
      <BarChart3 className="h-8 w-8 opacity-40" />
      <p>{message}</p>
    </div>
  )
}

export function EstadisticasView() {
  const [desde, setDesde] = useState<string>("")
  const [hasta, setHasta] = useState<string>("")

  // Filtros aplicados (se actualizan al pulsar "Aplicar" o en vivo; aquí en vivo para UX fluida)
  const desdeF = desde || undefined
  const hastaF = hasta || undefined

  const { data: resumen, isLoading: loadingResumen } = useResumen(desdeF, hastaF)
  const { data: porMes, isLoading: loadingMes } = usePorMes()
  const { data: porTipo, isLoading: loadingTipo } = usePorTipo(desdeF, hastaF)
  const { data: porArea, isLoading: loadingArea } = usePorArea(desdeF, hastaF)
  const { data: porTecnico, isLoading: loadingTecnico } = usePorTecnico(desdeF, hastaF)

  const r = resumen

  const limpiar = () => {
    setDesde("")
    setHasta("")
    toast.info("Filtros limpiados")
  }

  const exportarExcel = async () => {
    try {
      const qs = new URLSearchParams()
      if (desdeF) qs.set("desde", desdeF)
      if (hastaF) qs.set("hasta", hastaF)
      const path = `/exportar/estadisticas/excel${qs.toString() ? `?${qs}` : ""}`
      await apiDownload(path, "estadisticas.xlsx")
      toast.success("Excel exportado correctamente")
    } catch (e) {
      toast.error("No se pudo exportar: " + (e as Error).message)
    }
  }

  // Datos para gráfico de técnicos
  const tecnicoData = useMemo(() => {
    return (porTecnico?.items ?? []).map((t) => ({
      name: t.name,
      asignados: t.asignados,
      resueltos: t.resueltos,
    }))
  }, [porTecnico])

  const hayDatosMes = (porMes?.items ?? []).length > 0
  const hayDatosTipo = (porTipo?.items ?? []).length > 0
  const hayDatosArea = (porArea?.items ?? []).length > 0
  const hayDatosTecnico = tecnicoData.length > 0

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Estadísticas</h1>
          <p className="text-sm text-muted-foreground">
            Indicadores institucionales · {INSTITUCION.direccion}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={exportarExcel} className="gap-2 bg-institucional text-white hover:opacity-90">
            <FileSpreadsheet className="h-4 w-4" /> Exportar Excel
          </Button>
        </div>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader className="flex-row items-center gap-2 space-y-0">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <div className="flex-1">
            <CardTitle className="text-sm">Filtros de fecha</CardTitle>
            <CardDescription className="text-xs">
              Acota los indicadores a un rango temporal
            </CardDescription>
          </div>
          {(desde || hasta) && (
            <Button size="sm" variant="ghost" onClick={limpiar} className="gap-1 text-xs">
              <X className="h-3 w-3" /> Limpiar
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:gap-4">
            <div className="flex-1">
              <Label htmlFor="desde" className="text-xs">
                Desde
              </Label>
              <Input
                id="desde"
                type="date"
                value={desde}
                onChange={(e) => setDesde(e.target.value)}
                className="mt-1 max-w-[220px]"
              />
            </div>
            <div className="flex-1">
              <Label htmlFor="hasta" className="text-xs">
                Hasta
              </Label>
              <Input
                id="hasta"
                type="date"
                value={hasta}
                onChange={(e) => setHasta(e.target.value)}
                className="mt-1 max-w-[220px]"
              />
            </div>
            <Button variant="outline" size="sm" onClick={limpiar} className="gap-1">
              <X className="h-3 w-3" /> Limpiar filtros
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <KpiCard
          icon={ClipboardList}
          label="Total"
          value={r?.total ?? "—"}
          sub="Reportes en rango"
          iconColor="text-emerald-600"
          loading={loadingResumen}
        />
        <KpiCard
          icon={Clock}
          label="Pendientes"
          value={r?.pendientes ?? "—"}
          sub="Sin iniciar"
          iconColor="text-amber-600"
          loading={loadingResumen}
        />
        <KpiCard
          icon={Activity}
          label="En proceso"
          value={r?.enProceso ?? "—"}
          sub="En trabajo"
          iconColor="text-sky-600"
          loading={loadingResumen}
        />
        <KpiCard
          icon={CheckCircle2}
          label="Resueltos"
          value={r?.resueltos ?? "—"}
          sub="Atendidos"
          iconColor="text-emerald-600"
          loading={loadingResumen}
        />
        <KpiCard
          icon={PackageCheck}
          label="Cerrados"
          value={r?.cerrados ?? "—"}
          sub="Finalizados"
          iconColor="text-slate-600"
          loading={loadingResumen}
        />
        <KpiCard
          icon={ListChecks}
          label="Tiempo prom."
          value={`${r?.tiempoProm ?? "—"} h`}
          sub="Resolución media"
          iconColor="text-fuchsia-600"
          loading={loadingResumen}
        />
      </div>

      {/* Gráfico de línea — Reportes por mes */}
      <ChartCard
        title="Reportes por mes"
        description="Creados vs. resueltos (últimos 6 meses)"
      >
        {loadingMes ? (
          <ChartSkeleton />
        ) : !hayDatosMes ? (
          <EmptyState message="No hay datos mensuales disponibles" />
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={porMes?.items ?? []} margin={{ left: 0, right: 16, top: 8, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" opacity={0.35} />
              <XAxis dataKey="label" fontSize={11} stroke="#94a3b8" />
              <YAxis fontSize={11} stroke="#94a3b8" allowDecimals={false} />
              <Tooltip
                contentStyle={{ borderRadius: 8, fontSize: 12, border: "1px solid #e2e8f0" }}
                formatter={(v: number) => [v, ""]}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line
                type="monotone"
                dataKey="total"
                name="Creados"
                stroke={COLOR_TOTAL}
                strokeWidth={2.5}
                dot={{ r: 3 }}
                activeDot={{ r: 5 }}
              />
              <Line
                type="monotone"
                dataKey="resueltos"
                name="Resueltos"
                stroke={COLOR_RESUELTOS}
                strokeWidth={2.5}
                dot={{ r: 3 }}
                activeDot={{ r: 5 }}
                strokeDasharray="5 4"
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </ChartCard>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Pie — Distribución por tipo */}
        <ChartCard
          title="Distribución por tipo"
          description="Proporción de reportes según tipo de tarea"
        >
          {loadingTipo ? (
            <ChartSkeleton />
          ) : !hayDatosTipo ? (
            <EmptyState message="Sin reportes en el rango" />
          ) : (
            <>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={porTipo?.items ?? []}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={70}
                    innerRadius={36}
                    paddingAngle={2}
                  >
                    {(porTipo?.items ?? []).map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: 8, fontSize: 12, border: "1px solid #e2e8f0" }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 grid max-h-32 grid-cols-1 gap-1 overflow-y-auto scrollbar-thin text-[11px] sm:grid-cols-2">
                {(porTipo?.items ?? []).map((it, i) => (
                  <div key={it.name} className="flex items-center gap-1.5">
                    <span
                      className="h-2.5 w-2.5 shrink-0 rounded-sm"
                      style={{ background: CHART_COLORS[i % CHART_COLORS.length] }}
                    />
                    <span className="truncate text-muted-foreground">{it.name}</span>
                    <span className="ml-auto font-medium">{it.value}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </ChartCard>

        {/* Bar horizontal — Reportes por área */}
        <ChartCard
          title="Reportes por área"
          description="Distribución institucional"
        >
          {loadingArea ? (
            <ChartSkeleton />
          ) : !hayDatosArea ? (
            <EmptyState message="Sin reportes en el rango" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart
                data={porArea?.items ?? []}
                layout="vertical"
                margin={{ left: 10, right: 20, top: 8, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" opacity={0.35} />
                <XAxis type="number" fontSize={11} allowDecimals={false} stroke="#94a3b8" />
                <YAxis
                  type="category"
                  dataKey="name"
                  fontSize={11}
                  width={120}
                  stroke="#94a3b8"
                />
                <Tooltip
                  contentStyle={{ borderRadius: 8, fontSize: 12, border: "1px solid #e2e8f0" }}
                  cursor={{ fill: "rgba(16,185,129,0.08)" }}
                />
                <Bar
                  dataKey="value"
                  name="Reportes"
                  radius={[0, 4, 4, 0]}
                  fill={COLOR_TOTAL}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>

      {/* Carga por técnico */}
      <ChartCard
        title="Carga por técnico"
        description="Reportes asignados vs. resueltos por técnico"
      >
        {loadingTecnico ? (
          <ChartSkeleton />
        ) : !hayDatosTecnico ? (
          <EmptyState message="No hay técnicos con reportes en el rango" />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart
              data={tecnicoData}
              margin={{ left: 0, right: 16, top: 8, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.35} />
              <XAxis dataKey="name" fontSize={11} stroke="#94a3b8" />
              <YAxis fontSize={11} stroke="#94a3b8" allowDecimals={false} />
              <Tooltip
                contentStyle={{ borderRadius: 8, fontSize: 12, border: "1px solid #e2e8f0" }}
                cursor={{ fill: "rgba(16,185,129,0.06)" }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar
                dataKey="asignados"
                name="Asignados"
                fill={COLOR_ASIGNADOS}
                radius={[4, 4, 0, 0]}
              />
              <Bar
                dataKey="resueltos"
                name="Resueltos"
                fill={COLOR_TOTAL}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        )}
      </ChartCard>

      {/* Nota */}
      <Card className="bg-muted/30">
        <CardContent className="flex flex-col gap-1 p-4 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span>
            Datos calculados en vivo desde la base institucional · {INSTITUCION.sistema}
          </span>
          <span>
            Salud del sistema:{" "}
            <span className="font-semibold text-emerald-600">{r?.salud ?? "—"}/100</span>
            {" · "}
            Tasa de resolución:{" "}
            <span className="font-semibold text-sky-600">{r?.tasaResolucion ?? "—"}%</span>
          </span>
        </CardContent>
      </Card>
    </div>
  )
}
