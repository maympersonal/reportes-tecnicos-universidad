"use client"

import { useAppStore } from "@/lib/store"
import { INSTITUCION } from "@/lib/constants"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table"
import {
  Shield,
  ArrowLeft,
  Mail,
  Lock,
  Database,
  Globe,
  UserCheck,
  FileText,
  Eye,
  KeyRound,
  Server,
  AlertCircle,
  Scale,
  Trash2,
  Mailbox,
  ScanEye,
  Clock,
  ListChecks,
} from "lucide-react"
import { toast } from "sonner"

const ULTIMA_ACTUALIZACION = "1 de octubre de 2025"

const SECCIONES = [
  { id: "intro", label: "1. Introducción y responsable" },
  { id: "datos", label: "2. Datos que recogemos" },
  { id: "finalidades", label: "3. Finalidades del tratamiento" },
  { id: "base-legal", label: "4. Base legal" },
  { id: "derechos", label: "5. Derechos del titular" },
  { id: "olvido", label: "6. Derecho al olvido" },
  { id: "destinatarios", label: "7. Destinatarios y transferencias" },
  { id: "seguridad", label: "8. Medidas de seguridad" },
  { id: "ia", label: "9. Uso de Inteligencia Artificial" },
  { id: "contacto", label: "10. Contacto y reclamos" },
]

const DATOS_RECOGIDOS = [
  {
    dato: "Nombre y apellidos",
    finalidad: "Identificación del usuario y atribución de autoría de reportes.",
    base: "Cumplimiento de obligaciones contractuales (art. 10 Ley 1581).",
  },
  {
    dato: "Correo institucional",
    finalidad: "Notificaciones del sistema, recuperación de cuenta y reclamos.",
    base: "Ejecución del contrato y relación administrativa.",
  },
  {
    dato: "Nombre de usuario (username)",
    finalidad: "Inicio de sesión, trazabilidad y auditoría.",
    base: "Interés legítimo de seguridad informática.",
  },
  {
    dato: "Hash de contraseña (scrypt)",
    finalidad: "Autenticación segura. Nunca se almacena en texto claro.",
    base: "Medida técnica de seguridad (art. 15 Decreto 1377).",
  },
  {
    dato: "Cargo y teléfono",
    finalidad: "Asignación de roles y contacto operativo para soporte.",
    base: "Autorización expresa del titular.",
  },
  {
    dato: "Área de adscripción",
    finalidad: "Visibilidad de reportes según rol y dependencia.",
    base: "Necesidad operativa del servicio.",
  },
  {
    dato: "Direcciones IP y logs de sesión",
    finalidad: "Auditoría de accesos, prevención de fraude y soporte técnico.",
    base: "Interés legítimo (seguridad) art. 10 Ley 1581.",
  },
]

const FINALIDADES = [
  "Gestionar la creación, asignación, seguimiento y resolución de reportes técnicos en el ámbito de la institución.",
  "Mantener un historial auditable de cambios de estado, archivos adjuntos y notificaciones internas.",
  "Generar estadísticas agregadas y rankings de desempeño de los técnicos, con fines de mejora del servicio.",
  "Permitir la exportación de informes en formato Excel, PDF y Word para fines administrativos y de auditoría.",
  "Garantizar la seguridad de la información mediante el control de accesos, registro de sesiones y prevención de usos indebidos.",
  "Cumplir con las obligaciones legales y reglamentarias que correspondan al responsable del tratamiento.",
]

const DERECHOS_TITULAR = [
  {
    icon: Eye,
    title: "Acceder",
    text: "Conocer qué datos personales tiene el responsable y consultarlos de forma gratuita.",
  },
  {
    icon: UserCheck,
    title: "Actualizar",
    text: "Solicitar la actualización de los datos cuando hayan cambiado o sean incompletos.",
  },
  {
    icon: ScanEye,
    title: "Rectificar",
    text: "Corregir datos inexactos, parciales o erróneos que consten en el sistema.",
  },
  {
    icon: Trash2,
    title: "Suprimir",
    text: "Solicitar la supresión de los datos cuando no sean necesarios o el tratamiento sea ilícito.",
  },
  {
    icon: KeyRound,
    title: "Revocar autorización",
    text: "Retirar el consentimiento otorgado para el tratamiento de los datos personales.",
  },
]

const DESTINATARIOS = [
  {
    pais: "EE. UU. 🇺🇸",
    proveedor: "Supabase",
    finalidad: "Base de datos y autenticación del backend.",
    garantias: "Cláusulas contractuales tipo (SCC) y cifrado en tránsito y reposo.",
  },
  {
    pais: "EE. UU. 🇺🇸",
    proveedor: "Railway",
    finalidad: "Hosting del backend y orquestación de servicios.",
    garantias: "Acuerdo de tratamiento de datos y políticas de seguridad.",
  },
  {
    pais: "EE. UU. 🇺🇸",
    proveedor: "Netlify",
    finalidad: "Hosting del frontend y distribución de la SPA.",
    garantias: "Certificación SOC 2 y cumplimiento con estándares de la industria.",
  },
  {
    pais: "Francia 🇫🇷",
    proveedor: "Brevo",
    finalidad: "Envío de correos transaccionales y notificaciones.",
    garantias: "RGPD (UE) y compromisos de confidencialidad.",
  },
]

const MEDIDAS_SEGURIDAD = [
  {
    icon: KeyRound,
    title: "Hashing de contraseñas",
    text: "Las contraseñas se almacenan mediante el algoritmo scrypt con sal, impidiendo su recuperación en texto plano.",
  },
  {
    icon: Lock,
    title: "Sesiones con JWT firmado",
    text: "Cada sesión se representa con un token JWT firmado, con caducidad de 7 días y revocación centralizada.",
  },
  {
    icon: Globe,
    title: "Cifrado en tránsito (HTTPS)",
    text: "Todas las comunicaciones entre el cliente y el servidor se cifran mediante TLS 1.2+ (HTTPS).",
  },
  {
    icon: Shield,
    title: "Control de accesos por rol (RBAC)",
    text: "Visibilidad y permisos diferenciados para Administrador, Técnico y Auditor; la mínima exposición posible.",
  },
  {
    icon: Server,
    title: "Auditoría y logs",
    text: "Se registran accesos, cambios de estado y operaciones críticas para garantizar la trazabilidad.",
  },
  {
    icon: AlertCircle,
    title: "Principio de menor privilegio",
    text: "Cada usuario accede únicamente a la información necesaria para su función.",
  },
]

export function PrivacidadView() {
  const setView = useAppStore((s) => s.setView)

  const copiarCorreo = () => {
    navigator.clipboard?.writeText(INSTITUCION.correo)
    toast.success("Correo copiado al portapapeles")
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6 animate-fade-in-up px-1 pb-10">
      {/* Header institucional */}
      <Card className="overflow-hidden border-0 bg-institucional text-white shadow-md">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="space-y-2">
              <Badge
                variant="secondary"
                className="gap-1 bg-white/15 text-white hover:bg-white/20"
              >
                <Shield className="h-3 w-3" /> Documento legal
              </Badge>
              <h1 className="text-2xl font-bold sm:text-3xl">Política de Privacidad</h1>
              <p className="text-sm text-white/85">
                {INSTITUCION.sistema} · {INSTITUCION.direccion}
              </p>
              <p className="text-xs text-white/70">
                Conforme a la Ley 1581 de 2012 y el Decreto 1377 de 2013 — República de
                Colombia.
              </p>
              <p className="text-xs text-white/70">
                Última actualización: {ULTIMA_ACTUALIZACION}
              </p>
            </div>
            <Button
              variant="secondary"
              onClick={() => setView("dashboard")}
              className="gap-2 bg-white/15 text-white hover:bg-white/25 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" /> Volver
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Grid: sticky sidebar + content */}
      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        {/* Sticky index */}
        <aside className="hidden lg:block">
          <nav className="lg:sticky lg:top-20 lg:self-start">
            <Card className="p-4">
              <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Contenido
              </p>
              <ul className="space-y-1 text-sm">
                {SECCIONES.map((s) => (
                  <li key={s.id}>
                    <a
                      href={`#${s.id}`}
                      className="block rounded-md px-2 py-1.5 text-muted-foreground transition-colors hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-500/10 dark:hover:text-emerald-300"
                    >
                      {s.label}
                    </a>
                  </li>
                ))}
              </ul>
              <Separator className="my-3" />
              <Button
                size="sm"
                variant="outline"
                className="w-full gap-1 text-xs"
                onClick={copiarCorreo}
              >
                <Mail className="h-3 w-3" /> Copiar contacto
              </Button>
            </Card>
          </nav>
        </aside>

        {/* Content */}
        <div className="space-y-4">
          {/* 1. Introducción */}
          <Card id="intro" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-emerald-600" />
                <CardTitle>1. Introducción y responsable del tratamiento</CardTitle>
              </div>
              <CardDescription>
                Identidad del responsable y compromiso con la protección de datos.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm leading-relaxed text-muted-foreground">
              <p>
                La <strong className="text-foreground">{INSTITUCION.nombre}</strong>, a
                través de la <strong className="text-foreground">{INSTITUCION.direccion}</strong>{" "}
                y, específicamente, del{" "}
                <strong className="text-foreground">{INSTITUCION.departamento}</strong>, actúa
                como <strong className="text-foreground">responsable del tratamiento</strong>{" "}
                de los datos personales en el marco del{" "}
                <strong className="text-foreground">{INSTITUCION.sistema}</strong>. Esta
                plataforma se compromete a garantizar la privacidad y el ejercicio de los
                derechos de los titulares de datos, conforme a lo dispuesto en la Ley
                Estatutaria 1581 de 2012 y el Decreto 1377 de 2013.
              </p>
              <p>
                Esta política describe qué datos se recogen, con qué finalidad, durante cuánto
                tiempo, a qué destinatarios se comparten y cuáles son los derechos del titular
                para ejercer control sobre su información.
              </p>
              <Alert>
                <Scale className="h-4 w-4" />
                <AlertTitle>Marco normativo aplicable</AlertTitle>
                <AlertDescription>
                  Ley Estatutaria 1581 de 2012 (Protección de Datos Personales), Decreto 1377
                  de 2013 (reglamentario) y lineamientos de la Superintendencia de Industria y
                  Comercio (SIC).
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 2. Datos personales */}
          <Card id="datos" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Database className="h-5 w-5 text-emerald-600" />
                <CardTitle>2. Datos personales que recogemos</CardTitle>
              </div>
              <CardDescription>
                Inventario de datos tratados, su finalidad y base legal.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="overflow-hidden rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/40">
                      <TableHead className="min-w-[160px]">Dato personal</TableHead>
                      <TableHead>Finalidad</TableHead>
                      <TableHead className="min-w-[180px]">Base legal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DATOS_RECOGIDOS.map((row) => (
                      <TableRow key={row.dato}>
                        <TableCell className="font-medium">{row.dato}</TableCell>
                        <TableCell className="text-xs">{row.finalidad}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {row.base}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <Alert>
                <Lock className="h-4 w-4" />
                <AlertTitle>Principio de minimización</AlertTitle>
                <AlertDescription>
                  Solo se recogen los datos estrictamente necesarios para la prestación del
                  servicio. El sistema no solicita datos sensibles (salud, ideología,
                  biométricos, vida sexual, etc.).
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 3. Finalidades */}
          <Card id="finalidades" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <ListChecks className="h-5 w-5 text-emerald-600" />
                <CardTitle>3. Finalidades del tratamiento</CardTitle>
              </div>
              <CardDescription>
                Los datos se tratan exclusivamente para los siguientes fines.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                {FINALIDADES.map((f, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                    <span className="leading-relaxed">{f}</span>
                  </li>
                ))}
              </ul>
              <Alert className="mt-3">
                <Clock className="h-4 w-4" />
                <AlertTitle>Principio de temporalidad</AlertTitle>
                <AlertDescription>
                  Los datos se conservan durante el tiempo necesario para cumplir con la
                  finalidad descrita y, posteriormente, durante los plazos legales aplicables.
                  Cumplido dicho plazo, se anonimizan o suprimen.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 4. Base legal */}
          <Card id="base-legal" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Scale className="h-5 w-5 text-emerald-600" />
                <CardTitle>4. Base legal del tratamiento</CardTitle>
              </div>
              <CardDescription>
                Fundamento normativo conforme a la legislación colombiana.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm leading-relaxed text-muted-foreground">
              <p>
                El tratamiento de datos personales se realiza sobre la base de las siguientes
                causales legalmente reconocidas:
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5 shrink-0 font-mono text-xs">
                    Art. 5
                  </Badge>
                  <span>
                    <strong className="text-foreground">Autorización del titular.</strong>{" "}
                    El usuario consiente libre, previa, expresa e inequívocamente el tratamiento
                    de sus datos al crear su cuenta y aceptar esta política.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5 shrink-0 font-mono text-xs">
                    Art. 4
                  </Badge>
                  <span>
                    <strong className="text-foreground">Principios rectores.</strong> El
                    tratamiento se rige por los principios de legalidad, finalidad, libertad,
                    veracidad o calidad, transparencia, acceso restringido, seguridad y
                    confidencialidad.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5 shrink-0 font-mono text-xs">
                    Art. 10
                  </Badge>
                  <span>
                    <strong className="text-foreground">Causales habilitantes.</strong>{" "}
                    Ejecución de un contrato, cumplimiento de deberes legales y la atención de
                    intereses legítimos del responsable en materia de seguridad y auditoría.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Badge variant="outline" className="mt-0.5 shrink-0 font-mono text-xs">
                    Dec. 1377
                  </Badge>
                  <span>
                    <strong className="text-foreground">Reglamentación.</strong> El Decreto
                    1377 de 2013 desarrolla los lineamientos operativos para la gestión
                    adecuada de los datos personales por parte de los responsables.
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* 5. Derechos del titular */}
          <Card id="derechos" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-emerald-600" />
                <CardTitle>5. Derechos del titular (art. 8 Ley 1581)</CardTitle>
              </div>
              <CardDescription>
                Derechos que puede ejercer el titular sobre sus datos personales.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {DERECHOS_TITULAR.map((d) => (
                  <div
                    key={d.title}
                    className="rounded-lg border border-emerald-100 bg-emerald-50/40 p-4 dark:border-emerald-500/20 dark:bg-emerald-500/5"
                  >
                    <div className="flex items-center gap-2">
                      <d.icon className="h-4 w-4 text-emerald-600" />
                      <p className="text-sm font-semibold text-foreground">{d.title}</p>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{d.text}</p>
                  </div>
                ))}
              </div>
              <Alert className="mt-3">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Ejercicio gratuito</AlertTitle>
                <AlertDescription>
                  El ejercicio de los derechos es gratuito. El responsable responderá a la
                  solicitud en un plazo máximo de quince (15) días hábiles, conforme al art. 13
                  de la Ley 1581 de 2012.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 6. Derecho al olvido */}
          <Card id="olvido" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Trash2 className="h-5 w-5 text-emerald-600" />
                <CardTitle>6. Derecho al olvido y supresión</CardTitle>
              </div>
              <CardDescription>
                Cómo ejercer el derecho a la supresión dentro del sistema.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>
                El titular puede ejercer su derecho a la supresión de datos personales
                directamente desde la interfaz del sistema, sin necesidad de trámite
                administrativo adicional. El flujo es el siguiente:
              </p>
              <ol className="space-y-2">
                <li className="flex items-start gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                    1
                  </span>
                  <span>
                    Acceder al panel del usuario en la barra superior (avatar) y seleccionar{" "}
                    <strong className="text-foreground">“Eliminar mi cuenta”</strong>.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                    2
                  </span>
                  <span>
                    Confirmar la acción escribiendo{" "}
                    <code className="rounded bg-muted px-1 font-mono text-xs">ELIMINAR</code>{" "}
                    en el diálogo de confirmación.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                    3
                  </span>
                  <span>
                    El sistema <strong className="text-foreground">anonimiza</strong> los datos
                    personales, conserva los reportes atribuyéndolos a un usuario anónimo y
                    desactiva la cuenta. Las sesiones y notificaciones asociadas se eliminan.
                  </span>
                </li>
              </ol>
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Acción irreversible</AlertTitle>
                <AlertDescription>
                  Una vez completada, la operación no puede revertirse. La anonimización busca
                  preservar la integridad histórica del reporte técnico sin comprometer la
                  identidad del titular.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 7. Destinatarios */}
          <Card id="destinatarios" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-emerald-600" />
                <CardTitle>7. Destinatarios y transferencias internacionales</CardTitle>
              </div>
              <CardDescription>
                Terceros que actúan como encargados del tratamiento, con su país y finalidad.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="overflow-hidden rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/40">
                      <TableHead>País</TableHead>
                      <TableHead>Proveedor</TableHead>
                      <TableHead>Finalidad</TableHead>
                      <TableHead>Garantías</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DESTINATARIOS.map((d) => (
                      <TableRow key={d.proveedor}>
                        <TableCell className="text-xs">{d.pais}</TableCell>
                        <TableCell className="font-medium">{d.proveedor}</TableCell>
                        <TableCell className="text-xs">{d.finalidad}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {d.garantias}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <Alert>
                <Globe className="h-4 w-4" />
                <AlertTitle>Transferencias internacionales</AlertTitle>
                <AlertDescription>
                  Se han celebrado acuerdos con cláusulas contractuales tipo y se exige a cada
                  encargado el cumplimiento de estándares equivalentes a los previstos en la
                  legislación colombiana. La lista de proveedores puede actualizarse; cualquier
                  cambio se notificará a través de esta política.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 8. Medidas de seguridad */}
          <Card id="seguridad" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-emerald-600" />
                <CardTitle>8. Medidas de seguridad técnicas y organizativas</CardTitle>
              </div>
              <CardDescription>
                Salvaguardas implementadas para proteger los datos personales.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2">
                {MEDIDAS_SEGURIDAD.map((m) => (
                  <div
                    key={m.title}
                    className="rounded-lg border bg-card p-4 transition-colors hover:border-emerald-300 dark:hover:border-emerald-500/30"
                  >
                    <div className="flex items-center gap-2">
                      <m.icon className="h-4 w-4 text-emerald-600" />
                      <p className="text-sm font-semibold text-foreground">{m.title}</p>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{m.text}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 9. Declaración IA */}
          <Card id="ia" className="scroll-mt-20 border-emerald-200 bg-emerald-50/40 dark:border-emerald-500/20 dark:bg-emerald-500/5">
            <CardHeader>
              <div className="flex items-center gap-2">
                <ScanEye className="h-5 w-5 text-emerald-600" />
                <CardTitle>9. Declaración sobre uso de Inteligencia Artificial</CardTitle>
              </div>
              <CardDescription>
                Conforme al artículo 15 del Decreto 1377 de 2013.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>
                El <strong className="text-foreground">{INSTITUCION.sistema}</strong>{" "}
                <strong className="text-foreground">NO utiliza Inteligencia Artificial</strong>{" "}
                para tomar decisiones automatizadas que produzcan efectos jurídicos o afecten
                de manera significativa los intereses del titular, en cumplimiento del artículo
                15 del Decreto 1377 de 2013.
              </p>
              <p>
                Las decisiones dentro del sistema (asignación de técnicos, priorización de
                reportes, cálculo de rankings y métricas de desempeño) son producto de reglas
                deterministas y explícitas, configuradas por los administradores y
                supervisadas por humanos. Los reportes de estadísticas y rankings se calculan
                mediante fórmulas aritméticas públicas y auditables.
              </p>
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertTitle>Sin elaboración de perfiles automatizados</AlertTitle>
                <AlertDescription>
                  No se realiza elaboración de perfiles ni se realizan predicciones
                  automatizadas que afecten al titular. Cualquier análisis sobre los datos es
                  meramente estadístico y agregado.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* 10. Contacto */}
          <Card id="contacto" className="scroll-mt-20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Mailbox className="h-5 w-5 text-emerald-600" />
                <CardTitle>10. Contacto y reclamos</CardTitle>
              </div>
              <CardDescription>
                Canal habilitado para el ejercicio de derechos y presentación de reclamos.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>
                El titular podrá ejercer sus derechos de acceso, rectificación, actualización,
                supresión y revocación, así como presentar reclamos, dirigiéndose al
                responsable del tratamiento a través del canal oficial:
              </p>
              <div className="flex flex-col gap-2 rounded-lg border bg-muted/30 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-emerald-600" />
                  <div>
                    <p className="text-xs text-muted-foreground">Correo institucional</p>
                    <a
                      href={`mailto:${INSTITUCION.correo}`}
                      className="font-mono text-sm font-semibold text-foreground hover:text-emerald-600"
                    >
                      {INSTITUCION.correo}
                    </a>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="gap-1" onClick={copiarCorreo}>
                  <Mail className="h-3 w-3" /> Copiar
                </Button>
              </div>
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertTitle>Término de respuesta</AlertTitle>
                <AlertDescription>
                  Las peticiones de consulta se atenderán en un máximo de diez (10) días
                  hábiles y los reclamos en un máximo de quince (15) días hábiles, conforme a
                  los artículos 12 y 13 de la Ley 1581 de 2012. Si el titular considera que su
                  derecho ha sido vulnerado, podrá acudir a la Superintendencia de Industria y
                  Comercio.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Footer */}
          <Card className="bg-muted/30">
            <CardContent className="flex flex-col gap-2 p-4 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <Shield className="h-3 w-3" />
                <span>
                  Última actualización:{" "}
                  <strong className="text-foreground">{ULTIMA_ACTUALIZACION}</strong>
                </span>
              </div>
              <a
                href={`mailto:${INSTITUCION.correo}`}
                className="font-mono hover:text-emerald-600"
              >
                {INSTITUCION.correo}
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
