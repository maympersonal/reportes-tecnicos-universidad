"use client"

import { useAppStore } from "@/lib/store"
import { NAV_ITEMS, NAV_LEGAL, ROL_LABEL, INSTITUCION } from "@/lib/constants"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard, ClipboardList, Trophy, BarChart3, Shield, FileText,
  ChevronLeft, LogOut, Monitor, Wrench, CircleDot,
} from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useState } from "react"
import { EliminarCuentaDialog } from "@/components/app/eliminar-cuenta-dialog"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard, ClipboardList, Trophy, BarChart3, Shield, FileText,
}

function initials(name: string) {
  return name.split(" ").slice(0, 2).map((s) => s[0]).join("").toUpperCase()
}

export function Sidebar() {
  const collapsed = useAppStore((s) => s.sidebarCollapsed)
  const toggle = useAppStore((s) => s.toggleSidebar)
  const user = useAppStore((s) => s.user)
  const view = useAppStore((s) => s.view)
  const setView = useAppStore((s) => s.setView)
  const logout = useAppStore((s) => s.logout)
  const [eliminarOpen, setEliminarOpen] = useState(false)

  const navItem = (item: (typeof NAV_ITEMS)[number]) => {
    const Icon = iconMap[item.icon] ?? CircleDot
    const active = view === item.view
    return (
      <button
        key={item.view}
        onClick={() => setView(item.view)}
        className={cn(
          "group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          active
            ? "bg-primary text-primary-foreground shadow-sm"
            : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
          collapsed && "justify-center"
        )}
        title={collapsed ? item.label : undefined}
      >
        <Icon className="h-4 w-4 shrink-0" />
        {!collapsed && <span>{item.label}</span>}
      </button>
    )
  }

  return (
    <aside
      className={cn(
        "flex h-full flex-col border-r bg-sidebar text-sidebar-foreground transition-[width] duration-200",
        collapsed ? "w-[68px]" : "w-64"
      )}
    >
      {/* Header / logo */}
      <div className="flex items-center gap-2 border-b px-4 py-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-institucional text-white shadow-sm">
          <Wrench className="h-5 w-5" />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold leading-tight">Reportes Técnicos</p>
            <p className="truncate text-[11px] text-muted-foreground">Innovación Digital</p>
          </div>
        )}
      </div>

      {/* Navegación */}
      <ScrollArea className="flex-1 px-2 py-3">
        <nav className="space-y-1">
          {!collapsed && (
            <p className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Principal
            </p>
          )}
          {NAV_ITEMS.map(navItem)}
        </nav>
        <div className="mt-6 space-y-1">
          {!collapsed && (
            <p className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Legal
            </p>
          )}
          {NAV_LEGAL.map((item) => {
            const Icon = iconMap[item.icon] ?? CircleDot
            const active = view === item.view
            return (
              <button
                key={item.view}
                onClick={() => setView(item.view)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                  collapsed && "justify-center"
                )}
                title={collapsed ? item.label : undefined}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {!collapsed && <span>{item.label}</span>}
              </button>
            )
          })}
        </div>
      </ScrollArea>

      {/* Usuario + acciones */}
      <div className="border-t p-3">
        {user && (
          <div className={cn("flex items-center gap-2", collapsed && "justify-center")}>
            <Avatar className="h-9 w-9 border">
              <AvatarFallback className="bg-institucional text-xs font-semibold text-white">
                {initials(user.name)}
              </AvatarFallback>
            </Avatar>
            {!collapsed && (
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium leading-tight">{user.name}</p>
                <p className="flex items-center gap-1 truncate text-[11px] text-muted-foreground">
                  <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  {ROL_LABEL[user.role as keyof typeof ROL_LABEL] ?? user.role} · en línea
                </p>
              </div>
            )}
          </div>
        )}
        <div className={cn("mt-3 flex flex-col gap-1", collapsed && "items-center")}>
          <Button
            variant="ghost"
            size={collapsed ? "icon" : "sm"}
            className={cn(!collapsed && "w-full justify-start text-muted-foreground")}
            onClick={() => setEliminarOpen(true)}
            title="Eliminar mi cuenta"
          >
            <Shield className="h-4 w-4" />
            {!collapsed && <span className="text-xs">Eliminar cuenta</span>}
          </Button>
          <Button
            variant="ghost"
            size={collapsed ? "icon" : "sm"}
            className={cn(!collapsed && "w-full justify-start text-muted-foreground hover:text-destructive")}
            onClick={() => logout()}
            title="Cerrar sesión"
          >
            <LogOut className="h-4 w-4" />
            {!collapsed && <span className="text-xs">Cerrar sesión</span>}
          </Button>
        </div>
        <button
          onClick={toggle}
          className={cn(
            "mt-2 flex items-center justify-center rounded-md py-1 text-muted-foreground hover:bg-accent",
            collapsed ? "w-full" : "w-full"
          )}
          aria-label="Colapsar sidebar"
        >
          <ChevronLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />
        </button>
      </div>

      <EliminarCuentaDialog open={eliminarOpen} onOpenChange={setEliminarOpen} />
    </aside>
  )
}

export { Monitor }
