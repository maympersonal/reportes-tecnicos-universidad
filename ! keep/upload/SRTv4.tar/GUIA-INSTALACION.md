# 📘 Guía de Instalación y Ejecución — Sistema de Reportes Técnicos

Esta guía te explica, paso a paso, **todo lo que debes instalar en tu IDE Visual Studio Code (VSC)** y los **comandos para correr la app** en tu máquina.

> Stack: **Next.js 16 (React 19) · TypeScript · Tailwind CSS 4 · shadcn/ui · Prisma + SQLite · TanStack Query · Zustand · framer-motion · recharts**

---

## 1. Requisitos previos (software base)

Antes de abrir VSC, instala lo siguiente en tu sistema operativo (Windows / macOS / Linux):

### 1.1 Node.js (obligatorio)
- Versión recomendada: **Node.js 20 LTS o superior**.
- Descarga: <https://nodejs.org/>
- Verifica la instalación:
  ```bash
  node -v   # v20.x o superior
  npm -v
  ```

### 1.2 Bun (recomendado — gestor de paquetes ultra rápido)
El proyecto está configurado para correr con **Bun**.
- Instalación:
  ```bash
  # macOS / Linux / WSL
  curl -fsSL https://bun.sh/install | bash
  # Windows (PowerShell)
  powershell -c "irm bun.sh/install.ps1 | iex"
  ```
- Verifica:
  ```bash
  bun -v
  ```
- Si prefieres no usar Bun, puedes reemplazar `bun` por `npm` o `pnpm` en todos los comandos (ej. `npm run dev`).

### 1.3 Git
- Para clonar/versionar el proyecto. Descarga: <https://git-scm.com/>
- Verifica:
  ```bash
  git -v
  ```

### 1.4 (Opcional) Prisma CLI global
No es obligatorio: el proyecto ya incluye `prisma` como dependencia. Si quieres el CLI global:
```bash
bun add -g prisma
```

---

## 2. Configuración de Visual Studio Code

### 2.1 Descargar e instalar VSC
- <https://code.visualstudio.com/>

### 2.2 Extensiones recomendadas (instálalas desde el panel de extensiones `Ctrl+Shift+X`)

| Extensión | Autor | Para qué sirve |
|-----------|-------|----------------|
| **ES7+ React/Redux/React-Native snippets** | dsznajder | Snippets de React |
| **Tailwind CSS IntelliSense** | Tailwind Labs | Autocompletado de clases Tailwind |
| **Prisma** | Prisma | Highlight, formato y autocompletado del schema |
| **ESLint** | Microsoft | Linting en tiempo real |
| **Prettier - Code formatter** | Prettier | Formateo de código |
| **TypeScript Vue Plugin (Volar)** → en realidad usa **TypeScript IntelliSense** nativo | — | Tipado TS |
| **PostCSS Language Support** | PostCSS | Reconoce `@tailwind` y CSS moderno |
| **Pretty TypeScript Errors** | typescript-tools | Errores TS más legibles |
| **Auto Rename Tag** | Jun Han | Renombra etiquetas HTML/JSX en pares |
| **Path Intellisense** | Christian Kohler | Autocompletado de rutas |
| **Error Lens** | Alexander | Muestra errores inline |
| **GitLens** | GitKraken | Historial y blame de Git |
| **Console Ninja** | Wallaby.js | Logs de consola inline (opcional) |
| **Material Icon Theme** | Philipp Kief | Iconos de archivos (estético) |

### 2.3 Configuración recomendada de VSC (`Ctrl+,` → abrir JSON)
Crea/actualiza `.vscode/settings.json` en la raíz del proyecto:
```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.tabSize": 2,
  "files.eol": "\n",
  "tailwindCSS.experimental.classRegex": [
    "cva\\(\"([^\"]*)\"", "cn\\(([^)]*)\\)"
  ],
  "tailwindCSS.includeLanguages": { "typescriptreact": "html" },
  "prisma.fileWatch": true,
  "typescript.tsdk": "node_modules/typescript/lib"
}
```

---

## 3. Obtener el proyecto

Si recibes el proyecto como carpeta comprimida, descomprímela. Si está en Git:
```bash
git clone <url-del-repo>
cd reportes-tecnicos
```

Abre la carpeta en VSC:
```bash
code .
```
(O desde VSC: **Archivo → Abrir carpeta…**)

---

## 4. Instalar dependencias

En la terminal integrada de VSC (`` Ctrl+` ``):

```bash
bun install
```

Esto instala: `next`, `react`, `prisma`, `@prisma/client`, `tailwindcss`, `framer-motion`, `recharts`, `zustand`, `@tanstack/react-query`, `lucide-react`, `xlsx`, `jspdf`, `jspdf-autotable`, y todas las dependencias de shadcn/ui.

> Si no usas Bun: `npm install` (o `pnpm install`).

---

## 5. Configurar la base de datos

### 5.1 Variables de entorno
Crea un archivo `.env` en la raíz del proyecto con:
```env
DATABASE_URL="file:./db/custom.db"
```
> El proyecto usa **SQLite** (un archivo local). No necesitas instalar un servidor de base de datos. El archivo `.env` ya suele venir incluido.

### 5.2 Sincronizar el esquema (crear las tablas)
```bash
bun run db:push
```
Esto lee `prisma/schema.prisma` y crea/actualiza las tablas en `db/custom.db`.

### 5.3 Generar el cliente Prisma
```bash
bun run db:generate
```
> `db:push` ya ejecuta `generate`, pero es útil si cambias el schema.

### 5.4 Cargar datos de demostración (seed)
```bash
bun prisma/seed.ts
```
Esto crea:
- 6 usuarios (admin, 4 técnicos, 1 auditor).
- Tipos de área, áreas, ubicaciones, tipos de tarea.
- 53 reportes distribuidos en 6 meses, con historial y notificaciones.

**Credenciales de demostración (todas con contraseña `123456`):**

| Usuario | Rol |
|---------|-----|
| `admin` | Administrador (acceso total) |
| `tec1` | Técnico (crea reportes, ve los suyos) |
| `tec2`, `tec3`, `tec4` | Técnicos |
| `auditor` | Auditor (solo lectura + exportar) |

---

## 6. Ejecutar la aplicación (desarrollo)

```bash
bun run dev
```

VSC mostrará en la terminal:
```
▲ Next.js 16.1.3 (Turbopack)
- Local: http://localhost:3000
✓ Ready in 700ms
```

Abre **<http://localhost:3000>** en tu navegador. Verás la pantalla de login split-screen. Usa el botón **"Admin"** para autocompletar y **"Ingresar"**.

### Comandos disponibles (en `package.json`)
| Comando | Acción |
|---------|--------|
| `bun run dev` | Servidor de desarrollo con recarga en caliente (puerto 3000) |
| `bun run lint` | Verifica calidad del código con ESLint |
| `bun run db:push` | Sincroniza el schema Prisma con la BD |
| `bun run db:generate` | Regenera el cliente Prisma |
| `bun run db:migrate` | Crea migraciones (modo dev) |
| `bun run db:reset` | Borra y recrea la BD con migraciones |
| `bun run build` | Compila para producción |
| `bun run start` | Levanta el servidor de producción |

---

## 7. Estructura clave del proyecto

```
reportes-tecnicos/
├── prisma/
│   ├── schema.prisma         # Esquema de la BD (11 modelos)
│   └── seed.ts               # Datos de demostración
├── db/custom.db              # Base de datos SQLite (se crea con db:push)
├── public/uploads/          # Archivos adjuntos de reportes
├── src/
│   ├── app/
│   │   ├── page.tsx          # Ruta única "/" — monta Providers + AppShell (SPA)
│   │   ├── layout.tsx        # Layout raíz + metadata
│   │   ├── globals.css       # Estilos globales, tema, animaciones
│   │   └── api/              # Backend (API Routes Next.js)
│   │       ├── auth/         # login, me, eliminar (derecho al olvido)
│   │       ├── reportes/     # CRUD + cambiar-estado + archivos + historial
│   │       ├── estadisticas/ # resumen, por-mes, por-tipo, por-area, por-tecnico, ranking
│   │       ├── notificaciones/
│   │       ├── exportar/     # Excel (lista + estadísticas 5 hojas), PDF, Word
│   │       ├── tipos-area, areas, ubicaciones, tipos-tarea, tecnicos
│   ├── components/
│   │   ├── ui/               # Componentes shadcn/ui
│   │   ├── app/
│   │   │   ├── app-shell.tsx     # Layout + router de vistas (SPA)
│   │   │   ├── sidebar.tsx, topbar.tsx, notificaciones.tsx
│   │   │   ├── motion-primitives.tsx  # CountUp, Confetti, stagger
│   │   │   └── views/             # Dashboard, Reportes, Detalle, Form, Estadísticas, Ranking, Privacidad, Términos
│   │   └── providers.tsx     # TanStack Query + sync de tema
│   └── lib/
│       ├── constants.ts      # Estados, prioridades, roles, niveles
│       ├── auth.ts           # Hashing scrypt + sesiones
│       ├── db.ts             # Cliente Prisma
│       ├── api.ts            # Wrapper fetch (Bearer, 401, descargas)
│       ├── hooks.ts          # Hooks TanStack Query
│       ├── store.ts          # Zustand (auth, navegación, tema)
│       ├── serialize.ts      # Serializadores de reportes
│       └── stats.ts          # Lógica de visibilidad y ranking
└── .env
```

---

## 8. Verificar que todo funciona

1. `bun run lint` → debe dar **0 errores**.
2. `bun run dev` → sin errores en la terminal.
3. Abre <http://localhost:3000>, inicia sesión como `admin / 123456`.
4. Debes ver el **Dashboard** con KPIs animados, gráficos y tabla de recientes.
5. Navega a **Reportes → Nuevo reporte**, crea uno y verifica que te lleve al detalle.
6. Entra a **Ranking**: verás el podio animado (corona, confetti, score animado) y la tabla con barras de progreso.
7. Prueba **Estadísticas**, **Privacidad** y **Términos**.
8. Cambia a modo oscuro (botón 🌙 en el topbar) y redimensiona la ventana: el layout se adapta a móvil.

---

## 9. Compilar para producción (opcional)

```bash
bun run build
bun run start
```
> Por defecto el servidor de producción usa el puerto 3000.

---

## 10. Iteraciones futuras (app de escritorio y APK móvil)

La app web que acabas de montar es **100% React** y está pensada para empaquetarse como app de escritorio y como APK móvil sin reescribir el código.

### 10.1 App de escritorio (Tauri — recomendado, ligero)
Tauri usa el motor webview del sistema y un backend en Rust; produce binarios nativos pequeños.

```bash
# 1. Instalar Tauri CLI
bun add -D @tauri-apps/cli

# 2. Inicializar Tauri en el proyecto
bunx tauri init
# - Nombre de la app: Sistema de Reportes Técnicos
# - URL de desarrollo: http://localhost:3000
# - URL de producción: http://localhost:3000   (o un build estático)

# 3. Ajustar el dev server: Next.js debe escuchar en 0.0.0.0:3000
#    (en package.json: "dev": "next dev -H 0.0.0.0 -p 3000")

# 4. Compilar la app de escritorio
bunx tauri build
```
Salida: instalador `.msi`/`.exe` (Windows), `.dmg` (macOS), `.deb`/`.AppImage` (Linux).

### 10.2 APK móvil (Capacitor — iteración siguiente)
Capacitor envuelve la web app en un contenedor nativo Android/iOS.

```bash
# 1. Instalar Capacitor
bun add -D @capacitor/cli
bun add @capacitor/core @capacitor/android

# 2. Inicializar
bunx cap init "Reportes Técnicos" "cu.iris.reportes"

# 3. Compilar la web estática
bun run build

# 4. Añadir plataforma Android y sincronizar
bunx cap add android
bunx cap sync

# 5. Abrir en Android Studio para generar el APK
bunx cap open android
#    En Android Studio: Build → Build Bundle(s)/APK(s) → Build APK(s)
```
Requisitos: **Android Studio + JDK 17** instalados.

> Importante para móvil: la app ya usa `fetch` con rutas **relativas** (`/api/...`) y persistencia en `localStorage`, por lo que funciona dentro del webview de Capacitor sin cambios. Para producción móvil conviene apuntar la API a una URL pública (cambia `BASE` en `src/lib/api.ts` o usa una variable de entorno).

---

## 11. Solución de problemas comunes

| Problema | Solución |
|----------|----------|
| `Cannot find module '@prisma/client'` | Ejecuta `bun run db:generate` |
| `Database is locked` o errores de BD | Borra `db/custom.db` y vuelve a correr `bun run db:push` + `bun prisma/seed.ts` |
| El puerto 3000 está ocupado | Edita `package.json`: `"dev": "next dev -p 3001 ..."` |
| Cambios en `prisma/schema.prisma` no aplican | `bun run db:push` (acepta pérdida de datos en dev) |
| Errores de TypeScript tras cambiar el schema | `bun run db:generate` y reinicia el server (`Ctrl+C` → `bun run dev`) |
| Login falla | Verifica que corriste el seed (`bun prisma/seed.ts`); usuario: `admin`, pass: `123456` |
| Las notificaciones no actualizan | El polling es cada 30 s; revisa la consola del navegador (F12) |

---

## 12. Resumen de comandos (copia y pega)

```bash
# --- Primera vez ---
bun install
bun run db:push
bun prisma/seed.ts

# --- Desarrollo diario ---
bun run dev

# --- Calidad ---
bun run lint

# --- Producción ---
bun run build
bun run start

# --- Si modificas el schema Prisma ---
bun run db:push
```

---

**Contacto institucional:** innovacion.did@iris.uh.cu · Dirección de Innovación Digital

¿Dudas con algún paso? Revisa el archivo `worklog.md` en la raíz del proyecto para ver el historial completo de construcción.
